import argparse
import numpy as np
from sklearn.preprocessing import StandardScaler
from quaternion_smm.data.loader import load_cifar10_samples
from quaternion_smm.data.converter import RealToQuaternionConverter, convert_cifar10_to_quaternion
from quaternion_smm.core.qsmm import QSMMModel
from quaternion_smm.utils.splitter import train_test_split_by_class
from quaternion_smm.utils.metrics import accuracy, classification_report


def main(args):
    print(f"Loading CIFAR-10 data (k={args.k}, n_per_class={args.n_samples})...")
    
    X, y = load_cifar10_samples(
        n_per_class=args.n_samples,
        k=args.k,
        random_state=args.seed,
    )
    print(f"Loaded {X.shape[0]} samples, shape: {X.shape}")

    X_train, X_test, y_train, y_test = train_test_split_by_class(
        X, y, test_ratio=0.2, random_state=args.seed
    )
    del X,y
    print(f"Train: {X_train.shape[0]}, Test: {X_test.shape[0]}")
    
    # Flatten first, then normalize, then convert to quaternion
    X_train_flat = X_train.reshape(X_train.shape[0], -1).astype(np.float32)
    X_test_flat = X_test.reshape(X_test.shape[0], -1).astype(np.float32)
    print(f"Flattened: {X_train_flat.shape}")
    
    scaler = StandardScaler()
    X_train_flat = scaler.fit_transform(X_train_flat)
    X_test_flat = scaler.transform(X_test_flat)
    
    # Convert flattened data directly to quaternion dict
    n_features = X_train_flat.shape[1] // 4
    X_train_quat = {
        'real': X_train_flat[:, 0:n_features],
        'i': X_train_flat[:, n_features:2*n_features],
        'j': X_train_flat[:, 2*n_features:3*n_features],
        'k': X_train_flat[:, 3*n_features:4*n_features]
    }
    X_test_quat = {
        'real': X_test_flat[:, 0:n_features],
        'i': X_test_flat[:, n_features:2*n_features],
        'j': X_test_flat[:, 2*n_features:3*n_features],
        'k': X_test_flat[:, 3*n_features:4*n_features]
    }
    print(f"Converted to quaternion: {X_train_quat['i'].shape}")

    print(f"\nTraining QSMM model (k={args.k}, kernel={args.kernel}, C={args.C}, gamma={args.gamma})...")
    model = QSMMModel(
        C=args.C,
        gamma=args.gamma,
        theta=args.theta,
        rho=args.rho,
        mu = args.mu,
        max_iter=args.max_iter,
        verbose=args.verbose,
        kernel_type=args.kernel
    )

    y_quat = model._prepare_labels(y_train)

    print(f"Labels (quaternion format):")
    print(np.unique(y_quat, axis=0))
    # 以上代码已经过检查【np.where(y_train==0,-1,1) ==y_quat[:,0]]

    model.fit(X_train_quat, y_quat)
    print(f"Support vectors: {model.n_support}")
    
    print("\nPredicting...")
    y_pred = model.predict(X_test_quat)
    
    # Convert y_test to same format as y_train using model's label preparation
    y_test_quat = model._prepare_labels(y_test)

    y_test_binary = (y_test_quat[:, 0] > 0).astype(int)
    acc = accuracy(y_test_binary, y_pred)
    print(f"\nAccuracy: {acc:.4f}")
    
    if args.verbose:
        print("\n" + classification_report(y_test, y_pred))
    return model,acc

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Quaternion Support Matrix Machines")
    parser.add_argument("--k", type=int, default=2, help="Number of classes (must be even)")
    parser.add_argument("--n_samples", type=int, default=50, help="[Samples per class]")
    parser.add_argument("--C", type=float, default=0.1, help="Regularization parameter")
    parser.add_argument("--gamma", type=float, default=0.001, help="Kernel parameter")
    parser.add_argument("--theta", type=float, default=1, help="Ramp loss theta")
    parser.add_argument("--rho", type=float, default=1, help="ADMM penalty")
    parser.add_argument("--mu", type=float, default=0.01, help="ADMM dual step-size")
    parser.add_argument("--max_iter", type=int, default=100, help="ADMM max iterations")
    parser.add_argument("--seed", type=int, default=42, help="Random seed")
    parser.add_argument("--kernel", type=str, default='cubic', choices=['linear', 'gaussian', 'cubic'], help="Kernel type")
    parser.add_argument("--verbose", action="store_true", help="Verbose output")
    
    args = parser.parse_args()
    
    if args.k % 2 != 0:
        print("Error: k must be even")
        exit(1)
    
    model,acc=main(args)