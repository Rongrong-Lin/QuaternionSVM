import numpy as np
from sklearn.metrics.pairwise import rbf_kernel
from sklearn.preprocessing import StandardScaler
from quaternion_smm.core.kernel import QuaternionGaussianKernel as QGK
from quaternion_smm.data.loader import load_cifar10_samples
from quaternion_smm.core.real_quaternion_svm import R_right, quaternion_multiply


def test_kernel_scale():
    np.random.seed(42)
    
    X, y = load_cifar10_samples(n_per_class=200, k=2)
    X = X.reshape(X.shape[0], -1).astype(np.float32) / 255.0
    
    scaler = StandardScaler()
    X = scaler.fit_transform(X)
    
    gamma = 0.001
    
    n_features = X.shape[1] // 3
    X_dict = {
        'i': X[:, 0:n_features],
        'j': X[:, n_features:2*n_features],
        'k': X[:, 2*n_features:3*n_features]
    }
    
    qk = QGK(gamma=gamma)
    K_quat = qk.compute(X_dict)
    
    print(f"K_quat[:,:,0] max: {K_quat[:,:,0].max()}, min: {K_quat[:,:,0].min()}")
    print(f"K_quat[:,:,0] mean: {K_quat[:,:,0].mean()}")
    
    R_right_K = R_right(K_quat)
    R_right_KK = R_right(quaternion_multiply(K_quat, K_quat))
    
    print(f"\nR_right_K max: {np.abs(R_right_K).max()}")
    print(f"R_right_KK max: {np.abs(R_right_KK).max()}")
    
    N = X.shape[0]
    pi = np.random.randn(N * 4) * 0.1
    rhs = -R_right_K @ pi
    lhs = R_right_K + 0.1 * R_right_KK
    
    print(f"\nrhs max: {np.abs(rhs).max()}")
    print(f"lhs cond: {np.linalg.cond(lhs)}")


if __name__ == "__main__":
    test_kernel_scale()