import numpy as np
import sys
sys.path.insert(0, '/')

from smm import SupportMatrixMachine
from imagenette_loader import load_imagenette_samples
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score, classification_report
import warnings
warnings.filterwarnings('ignore')

# Load ImageNette data with 400 samples total (200 per class, 2 classes)
print("Loading ImageNette dataset with 2 classes (400 samples)...")
X_dict, y = load_imagenette_samples(n_per_class=200, split='train',
                                    data_dir=r'/data/imagenette2-160',
                                    img_size=(160, 160))

# Use only first 2 classes for binary classification
# First class = label 0 (class n01440764), second class = label 1 (class n02102040)
mask = y < 2  # Only first 2 classes
X_dict['i'] = X_dict['i'][mask]
X_dict['j'] = X_dict['j'][mask]
X_dict['k'] = X_dict['k'][mask]
y = y[mask]

print(f"Loaded {len(y)} samples with {len(np.unique(y))} classes")
print(f"Class distribution: {np.bincount(y)}")

# Create matrix-structured data for SMM
n_rows, n_cols = 20, 20  # 20x20 = 400 features per sample
n_features = n_rows * n_cols

X_list = []
for i in range(len(y)):
    # Reshape to 20x20 matrix using R and G channels
    R_mat = X_dict['i'][i][:n_features].reshape(n_rows, n_cols)
    G_mat = X_dict['j'][i][:n_features].reshape(n_rows, n_cols)
    X_mat = (R_mat + G_mat) / 2.0
    X_list.append(X_mat)

X = np.array(X_list)
print(f"Data shape for SMM: {X.shape}")

# Convert labels to {-1, 1}
y_binary = np.where(y == 0, -1, 1)
print(f"Labels: {np.unique(y_binary)}")

# Split data with stratification
X_train, X_test, y_train, y_test = train_test_split(
    X, y_binary, test_size=0.2, random_state=42, stratify=y_binary
)
print(f"Train size: {X_train.shape[0]}, Test size: {X_test.shape[0]}")
print(f"Train class distribution: {np.bincount((y_train + 1).astype(int))}")
print(f"Test class distribution: {np.bincount((y_test + 1).astype(int))}")

# Train SMM with tuned parameters
print("\nTraining SMM with tuned parameters...")
smm = SupportMatrixMachine(
    lambda_param=0.01,  # Smaller regularization
    gamma=0.3,          # More Frobenius penalty
    max_iter=1000,      # More iterations
    tol=1e-5            # Tighter tolerance
)
smm.fit(X_train, y_train)

# Evaluate
y_pred = smm.predict(X_test)
acc = accuracy_score(y_test, y_pred)
f1 = f1_score(y_test, y_pred)

print(f"\n{'='*50}")
print(f"SMM Results on ImageNette (2 classes, 400 samples)")
print(f"{'='*50}")
print(f"Accuracy: {acc:.4f}")
print(f"F1-Score: {f1:.4f}")
print(f"{'='*50}")
print("\nClassification Report:")
print(classification_report(y_test, y_pred))
