import numpy as np
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from utils import load_dataset, evaluate_model, print_metrics


def main(dataset_name):
    np.random.seed(1)

    print("=" * 60)
    print(f"Loading {dataset_name} dataset...")
    print("=" * 60)

    X, y = load_dataset(dataset_name, n_per_class=400, k=2)
    
    # Handle both dict format (flower17) and array format (other datasets)
    if isinstance(X, dict):
        # For flower17: X is a dict with keys 'real', 'i', 'j', 'k'
        # Combine i, j, k channels for standard SVM
        X_flat = np.hstack([X['i'], X['j'], X['k']])
        print(f"Using quaternion channels (i, j, k) combined: {X_flat.shape}")
    else:
        # For other datasets: X is (n_samples, h, w, c)
        X_flat = X.reshape(X.shape[0], -1).astype(np.float32) / 255.0
    
    print(f"Loaded {y.shape[0]} samples")

    # Stratified split by class
    idx_class0 = np.where(y == 0)[0]
    idx_class1 = np.where(y == 1)[0]
    
    # Split each class separately (70% train, 30% test)
    np.random.seed(1)
    n_train_class = int(0.7 * len(idx_class0))
    
    idx_train = np.concatenate([
        np.random.choice(idx_class0, n_train_class, replace=False),
        np.random.choice(idx_class1, n_train_class, replace=False)
    ])
    idx_test = np.concatenate([
        np.setdiff1d(idx_class0, idx_train),
        np.setdiff1d(idx_class1, idx_train)
    ])
    
    X_train = X_flat[idx_train]
    X_test = X_flat[idx_test]
    y_train = y[idx_train]
    y_test = y[idx_test]

    print(f"Train: {X_train.shape[0]}, Test: {X_test.shape[0]}")
    print(f"  y_train unique: {np.unique(y_train)}")
    print(f"  y_test unique: {np.unique(y_test)}")

    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)

    print("\n" + "=" * 60)
    print("Training sklearn SVM (RBF kernel)...")
    print("=" * 60)

    sk_svm = SVC(C=1.0, kernel='rbf')
    sk_svm.fit(X_train, y_train)

    train_metrics, test_metrics = evaluate_model(sk_svm, X_train, y_train, X_test, y_test, use_decision_function=False)
    print_metrics(train_metrics, test_metrics, model_name='sklearn SVM')


if __name__ == "__main__":
    main(dataset_name='stl10')