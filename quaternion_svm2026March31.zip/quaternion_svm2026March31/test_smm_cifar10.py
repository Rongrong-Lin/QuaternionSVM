import numpy as np
import sys
sys.path.insert(0, 'D:/Prototype Development and Testing/quaternionSMM')

from smm import SupportMatrixMachine
from utils import evaluate_model, print_metrics
import warnings
warnings.filterwarnings('ignore')

from quaternion_smm.data.loader import load_cifar10_samples

def image_to_gray_matrices(X):
    """将RGB图像数据转换为灰度矩阵格式
    
    Args:
        X: (n, h, w, 3) RGB图像数组
    
    Returns:
        X_gray: (n, h, w) 灰度图像矩阵
    """
    X = X.astype(np.float32) / 255.0
    
    R = X[:, :, :, 0]
    G = X[:, :, :, 1]
    B = X[:, :, :, 2]
    
    gray = 0.299 * R + 0.587 * G + 0.114 * B
    
    return gray


if __name__ == "__main__":
    print("=" * 60)
    print("Loading CIFAR-10 dataset...")
    print("=" * 60)
    
    X, y = load_cifar10_samples(n_per_class=300, k=2)
    print(f"Loaded {X.shape[0]} samples, shape: {X.shape}")
    
    X_gray = image_to_gray_matrices(X)
    print(f"Grayscale shape: {X_gray.shape}")
    
    del X
    
    test_ratio = 0.2
    n_train = int(len(y) * (1 - test_ratio))
    X_train = X_gray[:n_train]
    X_test = X_gray[n_train:]
    y_train, y_test = y[:n_train], y[n_train:]
    
    y_train_binary = np.where(y_train == 0, -1, 1)
    y_test_binary = np.where(y_test == 0, -1, 1)
    
    print(f"\nTrain: {y_train.shape[0]}, Test: {y_test.shape[0]}")
    print(f"  y_train unique: {np.unique(y_train_binary)}")
    print(f"  y_test unique: {np.unique(y_test_binary)}")
    
    print("\n" + "=" * 50)
    print("Training SMM...")
    print("=" * 50)
    
    smm = SupportMatrixMachine(
        lambda_param=0.01,
        gamma=0.5,
        max_iter=1000,
        tol=1e-5
    )
    smm.fit(X_train, y_train_binary)
    
    train_metrics, test_metrics = evaluate_model(
        smm, X_train, y_train_binary, X_test, y_test_binary, use_decision_function=True
    )
    print_metrics(train_metrics, test_metrics, model_name='SMM')
