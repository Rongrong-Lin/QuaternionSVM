import os
import numpy as np
from PIL import Image
import json

def load_imagenette_samples(n_per_class=None, k=2, split='train', data_dir='./data/imagenette2-160', img_size=(160, 160)):
    """
    Load ImageNette dataset and convert to format suitable for quaternion processing
    
    Args:
        n_per_class: Number of samples per class (None for all)
        k: Number of classes to load
        split: 'train' or 'val'
        data_dir: Path to ImageNette dataset
        img_size: Target image size (width, height)
    
    Returns:
        X_dict: {'real': real_array, 'i': i_array, 'j': j_array, 'k': k_array}
                where real is zeros, i=R, j=G, k=B channels flattened
        y: labels (0 to n_classes-1)
    """
    data_path = os.path.join(data_dir, split)
    
    if not os.path.exists(data_path):
        raise ValueError(f"Data directory {data_path} does not exist")
    
    # Get classes (sort for consistent ordering)
    all_classes = sorted([d for d in os.listdir(data_path) 
                     if os.path.isdir(os.path.join(data_path, d))])
    
    classes = all_classes[:k]
    
    print(f"Loading {split} data from {data_path}")
    print(f"Loading {len(classes)} classes: {classes}")
    
    X_list = []
    y_list = []
    class_counts = {}
    
    for idx, class_name in enumerate(classes):
        class_path = os.path.join(data_path, class_name)
        if not os.path.exists(class_path):
            continue
            
        # Get all image files in this class
        image_files = [f for f in os.listdir(class_path) 
                      if f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.tiff'))]
        
        # Limit samples per class if specified
        if n_per_class is not None:
            image_files = image_files[:n_per_class]
        
        class_counts[class_name] = len(image_files)
        print(f"  Class {class_name} ({idx}): {len(image_files)} images")
        
        # Load and preprocess images
        for img_file in image_files:
            img_path = os.path.join(class_path, img_file)
            try:
                # Load image
                img = Image.open(img_path).convert('RGB')
                
                # Resize if needed
                if img.size != img_size:
                    img = img.resize(img_size, Image.Resampling.LANCZOS)
                
                # Convert to numpy array
                img_array = np.array(img, dtype=np.float32)  # (H, W, 3)
                
                # Normalize to [0, 1]
                img_array = img_array / 255.0
                
                # Extract channels
                R = img_array[:, :, 0]  # Red
                G = img_array[:, :, 1]  # Green
                B = img_array[:, :, 2]  # Blue
                
                # Flatten to vectors
                H, W = R.shape
                R_flat = R.reshape(H * W)
                G_flat = G.reshape(H * W)
                B_flat = B.reshape(H * W)
                
                X_list.append((R_flat, G_flat, B_flat))
                y_list.append(idx)
                
            except Exception as e:
                print(f"Warning: Could not load image {img_path}: {e}")
                continue
    
    if len(X_list) == 0:
        raise ValueError("No images were loaded successfully")
    
    # Convert to arrays
    n_samples = len(X_list)
    n_pixels = X_list[0][0].shape[0]  # H * W
    
    # Initialize arrays
    real_part = np.zeros((n_samples, n_pixels), dtype=np.float32)  # Real part = 0
    i_part = np.zeros((n_samples, n_pixels), dtype=np.float32)    # Red channel
    j_part = np.zeros((n_samples, n_pixels), dtype=np.float32)    # Green channel
    k_part = np.zeros((n_samples, n_pixels), dtype=np.float32)    # Blue channel
    
    # Fill arrays
    for i, (R_flat, G_flat, B_flat) in enumerate(X_list):
        real_part[i, :] = 0.0  # Real part is always 0
        i_part[i, :] = R_flat  # i = Red
        j_part[i, :] = G_flat  # j = Green
        k_part[i, :] = B_flat  # k = Blue
    
    X_dict = {
        'real': real_part,
        'i': i_part,
        'j': j_part,
        'k': k_part
    }
    
    y = np.array(y_list, dtype=np.int64)
    
    print(f"\nLoaded {n_samples} total images")
    print(f"Each image flattened to {n_pixels} pixels")
    print(f"Class distribution: {class_counts}")
    
    return X_dict, y

def main():
    """Test the ImageNette loader"""
    print("Testing ImageNette loader for quaternion SVM")
    print("=" * 50)
    
    # Load a small sample for testing
    X_dict, y = load_imagenette_samples(n_per_class=20, split='train')
    
    print(f"\nData shapes:")
    print(f"  real: {X_dict['real'].shape}")
    print(f"  i: {X_dict['i'].shape}")
    print(f"  j: {X_dict['j'].shape}")
    print(f"  k: {X_dict['k'].shape}")
    print(f"  y: {y.shape}")
    print(f"  Labels: {np.unique(y)}")
    
    # Check data ranges
    print(f"\nData ranges:")
    print(f"  real: [{np.min(X_dict['real'])}, {np.max(X_dict['real'])}] (should be 0)")
    print(f"  i (Red): [{np.min(X_dict['i']):.4f}, {np.max(X_dict['i']):.4f}]")
    print(f"  j (Green): [{np.min(X_dict['j']):.4f}, {np.max(X_dict['j']):.4f}]")
    print(f"  k (Blue): [{np.min(X_dict['k']):.4f}, {np.max(X_dict['k']):.4f}]")
    return X_dict, y

if __name__ == "__main__":
    X_dict, y=main()