import numpy as np
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from sklearn.metrics.pairwise import linear_kernel
from quaternion_smm.data.loader import load_cifar10_samples
from quaternion_smm.core.real_quaternion_svm import RealQuaternionSVM, RealQuaternionKernel, BinaryQuaternionSVM
from quaternion_smm.core.kernel import QuaternionCubicKernel
from imagenette_loader import load_imagenette_samples
from utils import evaluate_model, print_metrics


def main():
    np.random.seed(42)
    
    print("=" * 60)
    print("Loading ImageNette dataset (n_per_class=100)...")
    print("=" * 60)
    
    # Load ImageNette data with quaternion format
    X_dict, y = load_imagenette_samples(n_per_class=200, k=2, split='train')
    print(f"Loaded {X_dict['real'].shape[0]} samples")
    print(f"X dict keys: {X_dict.keys()}")
    print(f"  real shape: {X_dict['real'].shape}")
    print(f"  i shape: {X_dict['i'].shape}")
    print(f"  j shape: {X_dict['j'].shape}")
    print(f"  k shape: {X_dict['k'].shape}")
    print(f"  y shape: {y.shape}")
    print(f"  y unique: {np.unique(y)}")
    
    # Shuffle data
    np.random.seed(42)
    indices = np.random.permutation(len(y))
    X_dict = {k: v[indices] for k, v in X_dict.items()}
    y = y[indices]
    
    # Split into train/test
    test_ratio = 0.2
    n_train = int(len(y) * (1 - test_ratio))
    
    # Split the dict data
    X_train_dict = {k: v[:n_train] for k, v in X_dict.items()}
    X_test_dict = {k: v[n_train:] for k, v in X_dict.items()}
    y_train, y_test = y[:n_train], y[n_train:]
    
    print(f"\nTrain: {y_train.shape[0]}, Test: {y_test.shape[0]}")
    print(f"  y_train unique: {np.unique(y_train)}")
    print(f"  y_test unique: {np.unique(y_test)}")
    
    print("\n" + "=" * 60)
    print("BinaryQuaternionSVM with ImageNette")
    print("=" * 60)
    
    rq_svm = BinaryQuaternionSVM(
        C=10.0 ,
    gamma = 0.001,
    rho = 0.1,
    mu = 0.05,
    max_iter = 3000,
        verbose=True
    )
    
    rq_svm.fit(X=X_train_dict, y=y_train, X_test=X_test_dict, y_test=y_test)
    
    train_metrics, test_metrics = evaluate_model(
        rq_svm, X_train_dict, y_train, X_test_dict, y_test, use_decision_function=True
    )
    
    print_metrics(train_metrics, test_metrics, model_name='BinaryQuaternionSVM')
    
    print("\n" + "=" * 60)
    print("Test Complete")
    print("=" * 60)


if __name__ == "__main__":
    main()