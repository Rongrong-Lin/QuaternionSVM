import numpy as np
from sklearn.metrics import f1_score, roc_auc_score, accuracy_score

from quaternion_smm.data.flower17_loader import load_flower17_samples
from quaternion_smm.data.loader import load_cifar10_samples
from quaternion_smm.data.stl10_loader import load_stl10_samples


def load_dataset(dataset_name, n_per_class=1000, k=2):
    datasets = {
        'cifar10': load_cifar10_samples,
        'stl10': load_stl10_samples,
        'flower17':load_flower17_samples
    }
    return datasets[dataset_name](n_per_class, k=k)


def compute_metrics(y_true, y_pred, y_score=None):
    train_acc = accuracy_score(y_true, y_pred)
    f1 = f1_score(y_true, y_pred, average='weighted')

    if y_score is not None:
        if y_score.ndim > 1:
            y_score = y_score[:, 0]
        auc = roc_auc_score(y_true, y_score)
    else:
        auc = None

    return {
        'accuracy': train_acc,
        'f1_score': f1,
        'auc': auc
    }


def evaluate_model(model, X_train, y_train, X_test, y_test, use_decision_function=False):
    y_train_pred = model.predict(X_train)
    y_test_pred = model.predict(X_test)

    train_metrics = compute_metrics(y_train, y_train_pred)

    if use_decision_function:
        y_test_score = model.decision_function(X_test)
    else:
        y_test_score = y_test_pred

    test_metrics = compute_metrics(y_test, y_test_pred, y_test_score)

    return train_metrics, test_metrics


def print_metrics(train_metrics, test_metrics, model_name='Model'):
    print(f"\n{'=' * 50}")
    print(f"{model_name} Evaluation Results")
    print(f"{'=' * 50}")
    print(f"{'Metric':<20} {'Train':<15} {'Test':<15}")
    print(f"{'-' * 50}")
    print(f"{'Accuracy':<20} {train_metrics['accuracy']:<15.4f} {test_metrics['accuracy']:<15.4f}")
    print(f"{'F1-Score':<20} {train_metrics['f1_score']:<15.4f} {test_metrics['f1_score']:<15.4f}")
    if test_metrics['auc'] is not None:
        print(f"{'AUC':<20} {'N/A':<15} {test_metrics['auc']:<15.4f}")
    print(f"{'=' * 50}\n")
