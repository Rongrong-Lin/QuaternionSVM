import numpy as np
from quaternion_smm.utils.metrics import accuracy, confusion_matrix
from quaternion_smm.utils.splitter import train_test_split_by_class


def test_accuracy():
    y_true = np.array([0, 1, 0, 1])
    y_pred = np.array([0, 1, 1, 1])
    acc = accuracy(y_true, y_pred)
    assert acc == 0.75


def test_split():
    np.random.seed(42)
    X = np.arange(100).reshape(50, 2)
    y = np.array([0]*25 + [1]*25)
    X_train, X_test, y_train, y_test = train_test_split_by_class(
        X, y, n_per_class=10, random_state=42
    )
    assert X_train.shape[0] == 16
    assert X_test.shape[0] == 4
