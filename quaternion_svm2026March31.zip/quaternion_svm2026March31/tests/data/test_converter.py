import numpy as np
import pytest
from quaternion_smm.data.converter import RealToQuaternionConverter


def test_converter_padding():
    converter = RealToQuaternionConverter()
    x = np.random.randn(10)
    q = converter.convert(x)
    assert q.shape == (4, 3)


def test_converter_no_padding():
    converter = RealToQuaternionConverter()
    x = np.random.randn(12)
    q = converter.convert(x)
    assert q.shape == (4, 3)


def test_converter_batch():
    converter = RealToQuaternionConverter()
    X = np.random.randn(5, 12)
    Q = converter.convert_batch(X)
    assert Q.shape == (5, 4, 3)
