import numpy as np
import pytest
from quaternion_smm.core.loss import ramp_loss_vectorized, ramp_loss_gradient_vectorized


def test_ramp_loss():
    t = np.array([1.0, -1.0, 2.0, -2.0])
    theta = 1.0
    result = ramp_loss_vectorized(t, theta)
    assert result.shape == t.shape


def test_ramp_loss_vectorized():
    t = np.array([1.0, -1.0, 2.0, -2.0])
    theta = 1.0
    result = ramp_loss_vectorized(t, theta)
    assert result.shape == t.shape


def test_ramp_loss_values():
    """测试特定值的ramp loss"""
    theta = 1.0
    # |t| >= theta: loss = 0
    assert np.isclose(ramp_loss_vectorized(np.array([2.0]), theta)[0], 0.0)
    assert np.isclose(ramp_loss_vectorized(np.array([-2.0]), theta)[0], 0.0)
    # |t| < theta: loss = (theta - |t|)^2 / theta
    expected = (1.0 - 0.5) ** 2 / 1.0
    assert np.isclose(ramp_loss_vectorized(np.array([0.5]), theta)[0], expected)
