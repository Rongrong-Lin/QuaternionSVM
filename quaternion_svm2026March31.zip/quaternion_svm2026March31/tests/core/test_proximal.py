import numpy as np
import pytest
from quaternion_smm.core.proximal import soft_threshold, box_constraint, quadratic_proximal


def test_soft_threshold():
    u = np.array([1.0, 2.0, -3.0, 4.0])
    rho = 1.0
    result = soft_threshold(u, rho)
    expected = np.array([0.0, 1.0, -2.0, 3.0])
    assert np.allclose(result, expected)


def test_box_constraint():
    u = np.array([-1.0, 0.5, 1.5])
    theta = 1.0
    result = box_constraint(u, theta)
    assert np.all(result >= 0) and np.all(result <= theta)


def test_quadratic_proximal():
    u = np.array([1.0, 2.0, 3.0])
    c = 1.0
    result = quadratic_proximal(u, c)
    expected = u / (1 + c)
    assert np.allclose(result, expected)
