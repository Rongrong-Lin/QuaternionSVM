import numpy as np
import pytest
from quaternion_smm.core.quaternion import Quaternion
from quaternion_smm.core.kernel import QuaternionKernel


def test_linear_kernel():
    np.random.seed(42)
    X = {'real': np.random.randn(5, 4), 'i': np.random.randn(5, 4), 'j': np.random.randn(5, 4), 'k': np.random.randn(5, 4)}
    kernel = QuaternionKernel(kernel_type='linear')
    K = kernel.compute(X)
    assert K.shape == (5, 5, 4)


def test_gaussian_kernel():
    np.random.seed(42)
    X = {'real': np.random.randn(5, 4), 'i': np.random.randn(5, 4), 'j': np.random.randn(5, 4), 'k': np.random.randn(5, 4)}
    kernel = QuaternionKernel(kernel_type='gaussian', gamma=0.1)
    K = kernel.compute(X)
    assert K.shape == (5, 5, 4)
