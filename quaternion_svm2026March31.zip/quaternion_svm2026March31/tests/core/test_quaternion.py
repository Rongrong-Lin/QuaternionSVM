import numpy as np
import pytest
from quaternion_smm.core.quaternion import Quaternion


def test_quaternion_creation():
    q = Quaternion([1, 2, 3, 4])
    assert q.shape == (4,)


def test_quaternion_conjugate():
    q = Quaternion([1, 2, 3, 4])
    conj = q.conjugate()
    assert np.allclose(conj.q, [1, -2, -3, -4])


def test_quaternion_norm():
    q = Quaternion([1, 2, 3, 4])
    assert np.isclose(q.norm(), np.sqrt(30))


def test_quaternion_multiplication():
    q1 = Quaternion([1, 2, 3, 4])
    q2 = Quaternion([5, 6, 7, 8])
    result = q1 * q2
    assert result.shape == (4,)
