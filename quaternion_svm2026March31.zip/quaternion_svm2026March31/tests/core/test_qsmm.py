import numpy as np
from quaternion_smm.core.qsmm import QSMMModel


def test_qsmm_init():
    model = QSMMModel(C=1.0, gamma=1.0, max_iter=100)
    assert model.C == 1.0


def test_qsmm_fit_predict():
    np.random.seed(42)
    X = np.random.randn(20, 12)
    y = np.array([0]*10 + [1]*10)
    
    X_quat = {
        'real': X[:, :3],
        'i': X[:, 3:6],
        'j': X[:, 6:9],
        'k': X[:, 9:12]
    }
    
    model = QSMMModel(C=1.0, gamma=1.0, max_iter=10, verbose=False)
    model.fit(X_quat, y)
    
    X_test = {
        'real': X[:5, :3],
        'i': X[:5, 3:6],
        'j': X[:5, 6:9],
        'k': X[:5, 9:12]
    }
    pred = model.predict(X_test)
    assert pred.shape == (5,)
