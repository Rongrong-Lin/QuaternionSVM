import numpy as np
from quaternion_smm.core.qsmm import QSMMModel
from quaternion_smm.utils.metrics import accuracy


def test_full_pipeline():
    np.random.seed(42)
    X = np.random.randn(40, 12)
    y = np.array([0]*20 + [1]*20)
    
    X_quat = {
        'real': X[:, :3],
        'i': X[:, 3:6],
        'j': X[:, 6:9],
        'k': X[:, 9:12]
    }
    
    model = QSMMModel(C=1.0, gamma=0.1, max_iter=10, verbose=False)
    model.fit(X_quat, y)
    
    X_test = {
        'real': X[:5, :3],
        'i': X[:5, 3:6],
        'j': X[:5, 6:9],
        'k': X[:5, 9:12]
    }
    pred = model.predict(X_test)
    assert pred.shape == (5,)
