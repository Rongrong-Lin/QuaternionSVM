import numpy as np
from quaternion_smm.core.real_quaternion_svm import BinaryQuaternionSVM
from quaternion_smm.data.stl10_loader import load_stl10_samples
from utils import evaluate_model, print_metrics


def image_to_quaternion_dict(X):
    """将图像数据转换为四元数dict格式"""
    n = X.shape[0]
    X = X.astype(np.float32) / 255.0
    
    R = X[:, :, :, 0]
    G = X[:, :, :, 1]
    B = X[:, :, :, 2]
    
    X_real = np.zeros((n, 96*96))
    X_i = R.reshape(n, -1)
    X_j = G.reshape(n, -1)
    X_k = B.reshape(n, -1)
    
    return {'real': X_real, 'i': X_i, 'j': X_j, 'k': X_k}


def test_parameters(C_val, gamma_val, rho_val, mu_val, max_iter_val=1000):
    """Test a specific parameter combination"""
    print(f"\nTesting: C={C_val}, gamma={gamma_val}, rho={rho_val}, mu={mu_val}, max_iter={max_iter_val}")
    
    np.random.seed(42)
    
    # Load data
    X, y = load_stl10_samples(n_per_class=200, k=2)
    X_dict = image_to_quaternion_dict(X)
    
    # Split data
    test_ratio = 0.2
    n_train = int(len(y) * (1 - test_ratio))
    X_train_dict = {k: v[:n_train] for k, v in X_dict.items()}
    X_test_dict = {k: v[n_train:] for k, v in X_dict.items()}
    y_train, y_test = y[:n_train], y[n_train:]
    
    # Create and train model
    rq_svm = BinaryQuaternionSVM(
        C=C_val, 
        gamma=gamma_val, 
        max_iter=max_iter_val, 
        rho=rho_val, 
        mu=mu_val, 
        verbose=False  # Set to False for cleaner output during tuning
    )
    rq_svm.fit(X=X_train_dict, y=y_train, X_test=X_test_dict, y_test=y_test)
    
    # Evaluate
    train_metrics, test_metrics = evaluate_model(
        rq_svm, X_train_dict, y_train, X_test_dict, y_test, use_decision_function=False
    )
    
    test_acc = test_metrics['accuracy']
    print(f"  Test Accuracy: {test_acc:.4f}")
    
    return test_acc


def main():
    print("Parameter Tuning for BinaryQuaternionSVM with Gaussian Kernel")
    print("=" * 60)
    
    # Baseline parameters from original script
    baseline_acc = test_parameters(1.0, 0.004, 0.003, 0.2, max_iter_val=500)
    print(f"\nBaseline accuracy: {baseline_acc:.4f}")
    
    # Test a few key parameter combinations
    test_configs = [
        # (C, gamma, rho, mu)
        (0.5, 0.002, 0.001, 0.1),
        (0.5, 0.004, 0.003, 0.2),
        (1.0, 0.004, 0.003, 0.2),
        (2.0, 0.004, 0.003, 0.2),
        (1.0, 0.002, 0.003, 0.2),
        (1.0, 0.008, 0.003, 0.2),
        (1.0, 0.004, 0.001, 0.2),
        (1.0, 0.004, 0.01, 0.2),
        (1.0, 0.004, 0.003, 0.1),
        (1.0, 0.004, 0.003, 0.5),
    ]
    
    best_acc = baseline_acc
    best_params = {'C': 1.0, 'gamma': 0.004, 'rho': 0.003, 'mu': 0.2}
    
    for C_val, gamma_val, rho_val, mu_val in test_configs:
        acc = test_parameters(C_val, gamma_val, rho_val, mu_val, max_iter_val=500)
        if acc > best_acc:
            best_acc = acc
            best_params = {'C': C_val, 'gamma': gamma_val, 'rho': rho_val, 'mu': mu_val}
    
    print("\n" + "=" * 60)
    print("Tuning Complete")
    print("=" * 60)
    print(f"Best accuracy: {best_acc:.4f}")
    print(f"Best parameters: C={best_params['C']}, gamma={best_params['gamma']}, "
          f"rho={best_params['rho']}, mu={best_params['mu']}")
    
    # Final test with best parameters
    print("\n" + "=" * 40)
    print("Final evaluation with best parameters")
    print("=" * 40)
    final_acc = test_parameters(
        best_params['C'], 
        best_params['gamma'], 
        best_params['rho'], 
        best_params['mu'],
        max_iter_val=1000
    )
    print(f"Final test accuracy: {final_acc:.4f}")


if __name__ == "__main__":
    main()