import numpy as np

from quaternion_smm.core.real_quaternion_svm import RealQuaternionSVM, RealQuaternionKernel, BinaryQuaternionSVM
from quaternion_smm.data.flower17_loader import load_flower17_samples
from quaternion_smm.data.stl10_loader import load_stl10_samples
from utils import evaluate_model, print_metrics


def image_to_quaternion_dict(X):
    """将图像数据转换为四元数dict格式
    
    Args:
        X: (n, h, w, 3) 图像数组
    
    Returns:
        X_dict: {'real': real, 'i': i, 'j': j, 'k': k}
            - real: 全0
            - i: R通道
            - j: G通道  
            - k: B通道
    """
    n = X.shape[0]
    X = X.astype(np.float32) / 255.0
    
    R = X[:, :, :, 0]
    G = X[:, :, :, 1]
    B = X[:, :, :, 2]
    
    X_real = np.zeros((n, R.shape[1] * R.shape[2]))
    X_i = R.reshape(n, -1)
    X_j = G.reshape(n, -1)
    X_k = B.reshape(n, -1)
    
    return {'real': X_real, 'i': X_i, 'j': X_j, 'k': X_k}


def main():
    np.random.seed(42)
    
    print("=" * 60)
    print("Loading Flower17 dataset (n_per_class=40)...")
    print("=" * 60)
    
    X, y = load_stl10_samples(n_per_class=200, k=2)
    print(f"Loaded {X.shape[0]} samples, shape: {X.shape}")
    
    X_dict = image_to_quaternion_dict(X)
    print(f"  real shape: {X_dict['real'].shape}")
    print(f"  i shape: {X_dict['i'].shape}")
    print(f"  j shape: {X_dict['j'].shape}")
    print(f"  k shape: {X_dict['k'].shape}")
    
    test_ratio = 0.2
    n_train = int(len(y) * (1 - test_ratio))
    X_train_dict = {k: v[:n_train] for k, v in X_dict.items()}
    X_test_dict = {k: v[n_train:] for k, v in X_dict.items()}
    y_train, y_test = y[:n_train], y[n_train:]
    
    print(f"Train: {y_train.shape[0]}, Test: {y_test.shape[0]}")
    print(f"  y_train unique: {np.unique(y_train)}")
    print(f"  y_test unique: {np.unique(y_test)}")
    
    print("\n" + "=" * 60)
    print("BinaryQuaternionSVM with Flower17")
    print("=" * 60)
    
    rq_svm = BinaryQuaternionSVM(C=1.0, gamma=0.001, max_iter=100, rho=0.2, mu=0.05, verbose=True)
    rq_svm.fit(X=X_train_dict, y=y_train, X_test=X_test_dict, y_test=y_test)
    
    train_metrics, test_metrics = evaluate_model(
        rq_svm, X_train_dict, y_train, X_test_dict, y_test, use_decision_function=True
    )
    print_metrics(train_metrics, test_metrics, model_name='BinaryQuaternionSVM')
    
    print("\n" + "=" * 60)
    print("Test Complete")
    print("=" * 60)


if __name__ == "__main__":
    main()