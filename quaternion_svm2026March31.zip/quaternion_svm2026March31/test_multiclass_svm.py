import numpy as np
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from quaternion_smm.data.loader import load_cifar10_samples


def one_vs_one_train(X_train, y_train, C=1.0):
    """One-vs-One 多分类训练"""
    classes = np.unique(y_train)
    n_classes = len(classes)
    classifiers = {}
    
    for i in range(n_classes):
        for j in range(i + 1, n_classes):
            cls_i, cls_j = classes[i], classes[j]
            mask = (y_train == cls_i) | (y_train == cls_j)
            X_cls = X_train[mask]
            y_cls = y_train[mask]
            y_cls_binary = np.where(y_cls == cls_i, 0, 1)
            
            clf = SVC(C=C, kernel='linear')
            clf.fit(X_cls, y_cls_binary)
            classifiers[(cls_i, cls_j)] = clf
    
    return classifiers, classes


def one_vs_one_predict(X_test, classifiers, classes):
    """One-vs-One 多分类预测 (投票法)"""
    n_samples = X_test.shape[0]
    n_classes = len(classes)
    votes = np.zeros((n_samples, n_classes))
    
    for (cls_i, cls_j), clf in classifiers.items():
        preds = clf.predict(X_test)
        votes[preds == 0, cls_i] += 1
        votes[preds == 1, cls_j] += 1
    
    return classes[np.argmax(votes, axis=1)]


def one_vs_all_train(X_train, y_train, C=1.0):
    """One-vs-All 多分类训练"""
    classes = np.unique(y_train)
    n_classes = len(classes)
    classifiers = {}
    
    for cls in classes:
        y_binary = np.where(y_train == cls, 1, -1)
        clf = SVC(C=C, kernel='linear')
        clf.fit(X_train, y_binary)
        classifiers[cls] = clf
    
    return classifiers, classes


def one_vs_all_predict(X_test, classifiers, classes):
    """One-vs-All 多分类预测 (决策函数法)"""
    n_samples = X_test.shape[0]
    n_classes = len(classes)
    scores = np.zeros((n_samples, n_classes))
    
    for i, cls in enumerate(classes):
        scores[:, i] = classifiers[cls].decision_function(X_test)
    
    return classes[np.argmax(scores, axis=1)]


def main():
    np.random.seed(42)
    
    print("=" * 60)
    print("加载CIFAR-10数据 (每类80个, 4类)")
    print("=" * 60)
    
    X, y = load_cifar10_samples(n_per_class=80, k=4, random_state=42)
    print(f"Loaded {X.shape[0]} samples")
    
    X_flat = X.reshape(X.shape[0], -1).astype(np.float32) / 255.0
    del X
    
    scaler = StandardScaler()
    X_flat = scaler.fit_transform(X_flat)
    
    test_ratio = 0.2
    n_train = int(len(y) * (1 - test_ratio))
    X_train, X_test = X_flat[:n_train], X_flat[n_train:]
    y_train, y_test = y[:n_train], y[n_train:]
    
    print(f"Train: {X_train.shape[0]}, Test: {X_test.shape[0]}")
    print(f"Classes: {np.unique(y_train)}")
    
    print("\n" + "=" * 60)
    print("sklearn SVM (One-vs-One, linear)")
    print("=" * 60)
    
    sk_clf = SVC(C=1.0, kernel='linear')
    sk_clf.fit(X_train, y_train)
    sk_preds = sk_clf.predict(X_test)
    sk_acc = np.mean(sk_preds == y_test)
    print(f"sklearn OvO 准确率: {sk_acc:.4f}")
    
    print("\n" + "=" * 60)
    print("One-vs-One (手动实现)")
    print("=" * 60)
    
    classifiers, classes = one_vs_one_train(X_train, y_train, C=1.0)
    ovo_preds = one_vs_one_predict(X_test, classifiers, classes)
    ovo_acc = np.mean(ovo_preds == y_test)
    print(f"OvO 准确率: {ovo_acc:.4f}")
    print(f"差异: {abs(ovo_acc - sk_acc):.4f}")
    
    print("\n" + "=" * 60)
    print("One-vs-All (手动实现)")
    print("=" * 60)
    
    classifiers, classes = one_vs_all_train(X_train, y_train, C=1.0)
    ova_preds = one_vs_all_predict(X_test, classifiers, classes)
    ova_acc = np.mean(ova_preds == y_test)
    print(f"OvA 准确率: {ova_acc:.4f}")
    print(f"差异: {abs(ova_acc - sk_acc):.4f}")
    
    print("\n" + "=" * 60)
    print("测试完成")
    print("=" * 60)


if __name__ == "__main__":
    main()
