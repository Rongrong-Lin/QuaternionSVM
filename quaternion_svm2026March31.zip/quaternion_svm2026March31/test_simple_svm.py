import numpy as np
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from sklearn.metrics.pairwise import linear_kernel, rbf_kernel
from quaternion_smm.data.loader import load_cifar10_samples
from quaternion_smm.utils.splitter import train_test_split_by_class


def simple_svm(X_train, y_train, X_test, kernel='linear', C=1.0, gamma=0.01):
    """简化版SVM - 使用sklearn的核函数，只实现hinge loss的ADMM"""
    n = X_train.shape[0]
    
    if kernel == 'linear':
        K = X_train @ X_train.T
    else:
        X_sq = np.sum(X_train**2, axis=1, keepdims=True)
        XY = X_train @ X_train.T
        sq_dists = X_sq + X_sq.T - 2 * XY
        K = np.exp(-gamma * sq_dists)
    
    K = K / (np.linalg.norm(K) + 1e-10)
    
    y = np.where(y_train == 0, -1, 1)
    
    alpha = np.zeros(n)
    b = 0.0
    rho = 1.0
    
    for it in range(100):
        for i in range(n):
            error = y[i] * (np.dot(K[i], alpha * y) + b) - 1
            if error > 0:
                alpha[i] += rho * error / (K[i, i] + 1e-10)
                alpha[i] = min(alpha[i], C)
        
        b = np.mean(y - np.dot(K, alpha * y))
    
    if kernel == 'linear':
        K_test = X_test @ X_train.T
    else:
        X_test_sq = np.sum(X_test**2, axis=1, keepdims=True)
        X_train_sq = np.sum(X_train**2, axis=1, keepdims=True)
        XY_test = X_test @ X_train.T
        sq_dists_test = X_test_sq + X_train_sq.T - 2 * XY_test
        K_test = np.exp(-gamma * sq_dists_test)
    
    K_test = K_test / (np.linalg.norm(K) + 1e-10)
    
    decision = K_test @ (alpha * y) + b
    return np.sign(decision)


if __name__ == "__main__":
    np.random.seed(42)
    
    print("加载CIFAR-10...")
    X, y = load_cifar10_samples(n_per_class=100, k=2, random_state=42, return_images=True)
    
    X_train, X_test, y_train, y_test = train_test_split_by_class(X, y, test_ratio=0.2, random_state=42)
    
    X_train_flat = X_train.reshape(X_train.shape[0], -1).astype(np.float32)
    X_test_flat = X_test.reshape(X_test.shape[0], -1).astype(np.float32)
    
    scaler = StandardScaler()
    X_train_flat = scaler.fit_transform(X_train_flat)
    X_test_flat = scaler.transform(X_test_flat)
    
    print(f"Train: {X_train_flat.shape}, Test: {X_test_flat.shape}")
    
    print("\n测试线性核:")
    sk_svm = SVC(C=1.0, kernel='linear')
    sk_svm.fit(X_train_flat, y_train)
    sk_preds = sk_svm.predict(X_test_flat)
    print(f"sklearn: {np.mean(sk_preds == y_test):.4f}")
    
    simple_preds = simple_svm(X_train_flat, y_train, X_test_flat, kernel='linear', C=1.0)
    print(f"simple: {np.mean(simple_preds == y_test):.4f}")
    
    print("\n测试RBF核:")
    sk_svm_rbf = SVC(C=1.0, kernel='rbf', gamma=0.01)
    sk_svm_rbf.fit(X_train_flat, y_train)
    sk_preds_rbf = sk_svm_rbf.predict(X_test_flat)
    print(f"sklearn: {np.mean(sk_preds_rbf == y_test):.4f}")
    
    simple_preds_rbf = simple_svm(X_train_flat, y_train, X_test_flat, kernel='rbf', C=1.0, gamma=0.01)
    print(f"simple: {np.mean(simple_preds_rbf == y_test):.4f}")
