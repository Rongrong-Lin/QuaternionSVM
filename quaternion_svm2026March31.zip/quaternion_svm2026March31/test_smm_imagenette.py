import numpy as np
import sys
sys.path.insert(0, '/')

from smm import SupportMatrixMachine
from imagenette_loader import load_imagenette_samples
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score, classification_report

# Load ImageNette data with 400 samples total (200 per class, 2 classes)
print("Loading ImageNette dataset...")
X_dict, y = load_imagenette_samples(n_per_class=200, split='train',
                                    data_dir=r'/data/imagenette2-160',
                                    img_size=(160, 160))

print(f"Loaded {len(y)} samples")
print(f"Class distribution: {np.bincount(y)}")

# Convert to matrix format for SMM
# SMM expects shape (n_samples, n_rows, n_cols)
# We'll use i(R), j(G), k(B) channels as a 2x2 matrix structure
# For 160x160 images, reshape to matrices

# Get image dimensions
n_pixels = X_dict['i'].shape[1]  # Should be 160*160 = 25600
img_size = int(np.sqrt(n_pixels))  # 160

# Create matrix-structured data for SMM
# For simplicity, we'll use a smaller matrix by taking first n_rows * n_cols elements
# This keeps the algorithm tractable while still testing the approach
n_rows, n_cols = 20, 20  # 20x20 = 400 features per sample (much smaller than full image)

# Take first n_rows*n_cols pixels for matrix representation
n_features = n_rows * n_cols

# Stack channels into matrix format: each sample is a 2D matrix
# We can create a matrix by combining different channel information
# For demonstration: use R channel as real part, G as imaginary i, B as j
# But since SMM uses matrices, let's use a 20x20 reshaped from pixels

X_list = []
for i in range(len(y)):
    # Reshape each channel to 20x20 matrix
    R_mat = X_dict['i'][i][:n_features].reshape(n_rows, n_cols)  # Red
    G_mat = X_dict['j'][i][:n_features].reshape(n_rows, n_cols)  # Green
    # Combine into a single matrix (e.g., average of channels)
    X_mat = (R_mat + G_mat) / 2.0
    X_list.append(X_mat)

X = np.array(X_list)
print(f"Data shape for SMM: {X.shape}")  # (n_samples, 20, 20)

# Convert labels to {-1, 1}
y_binary = np.where(y == 0, -1, 1)
print(f"Labels: {np.unique(y_binary)}")

# Split data
X_train, X_test, y_train, y_test = train_test_split(X, y_binary, test_size=0.2, random_state=42, stratify=y_binary)
print(f"Train size: {X_train.shape[0]}, Test size: {X_test.shape[0]}")

# Train SMM
print("\nTraining SMM...")
smm = SupportMatrixMachine(lambda_param=0.1, gamma=0.5, max_iter=500, tol=1e-4)
smm.fit(X_train, y_train)

# Evaluate
y_pred = smm.predict(X_test)
acc = accuracy_score(y_test, y_pred)
f1 = f1_score(y_test, y_pred)

print(f"\n{'='*50}")
print(f"SMM Results on ImageNette (400 samples)")
print(f"{'='*50}")
print(f"Accuracy: {acc:.4f}")
print(f"F1-Score: {f1:.4f}")
print(f"{'='*50}")
print("\nClassification Report:")
print(classification_report(y_test, y_pred))
