import os
import tarfile
import urllib.request
from pathlib import Path
import json
from PIL import Image
import numpy as np

def download_imagenette_160(data_dir="./data"):
    """
    Download and extract ImageNette 160px dataset
    
    Args:
        data_dir: Directory to store the dataset
    
    Returns:
        Path to the extracted dataset
    """
    # Create data directory if it doesn't exist
    os.makedirs(data_dir, exist_ok=True)
    
    # URL for ImageNette 160px
    url = "https://s3.amazonaws.com/fast-ai-imageclas/imagenette2-160.tgz"
    filename = "imagenette2-160.tgz"
    filepath = os.path.join(data_dir, filename)
    extract_dir = os.path.join(data_dir, "imagenette2-160")
    
    # Check if already extracted
    if os.path.exists(extract_dir):
        print(f"ImageNette 160px already exists at {extract_dir}")
        return extract_dir
    
    # Download if not exists
    if not os.path.exists(filepath):
        print(f"Downloading ImageNette 160px from {url}...")
        
        def _progress(count, block_size, total_size):
            pct = float(count * block_size) / float(total_size) * 100.0
            print(f'\rDownloading {filename}: {pct:.1f}%', end='', flush=True)
        
        filepath, _ = urllib.request.urlretrieve(url, filepath, reporthook=_progress)
        print(f'\nDownloaded {filename}')
    else:
        print(f"File {filename} already exists")
    
    # Extract
    print(f'Extracting {filename}...')
    with tarfile.open(filepath, 'r:gz') as tar:
        tar.extractall(path=data_dir)
    print('Extracted.')
    
    return extract_dir

def load_imagenette_info(data_dir):
    """
    Load and display basic information about the ImageNette dataset
    
    Args:
        data_dir: Path to the extracted dataset
    """
    print("\n" + "="*50)
    print("ImageNette 160px Dataset Information")
    print("="*50)
    
    # Check structure
    train_dir = os.path.join(data_dir, 'train')
    val_dir = os.path.join(data_dir, 'val')
    
    if not os.path.exists(train_dir):
        print("Error: Could not find train directory")
        return
    
    # Get classes
    classes = sorted([d for d in os.listdir(train_dir) 
                     if os.path.isdir(os.path.join(train_dir, d))])
    print(f"Number of classes: {len(classes)}")
    print(f"Classes: {classes}")
    
    # Count images
    train_counts = {}
    val_counts = {}
    total_train = 0
    total_val = 0
    
    for cls in classes:
        train_cls_dir = os.path.join(train_dir, cls)
        val_cls_dir = os.path.join(val_dir, cls)
        
        if os.path.exists(train_cls_dir):
            train_count = len([f for f in os.listdir(train_cls_dir) 
                              if f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.tiff'))])
            train_counts[cls] = train_count
            total_train += train_count
        
        if os.path.exists(val_cls_dir):
            val_count = len([f for f in os.listdir(val_cls_dir) 
                            if f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.tiff'))])
            val_counts[cls] = val_count
            total_val += val_count
    
    print(f"\nTraining images: {total_train}")
    print(f"Validation images: {total_val}")
    print(f"Total images: {total_train + total_val}")
    
    print("\nPer-class breakdown:")
    print("-" * 30)
    for cls in classes:
        train_c = train_counts.get(cls, 0)
        val_c = val_counts.get(cls, 0)
        print(f"{cls:15} | Train: {train_c:4} | Val: {val_c:4} | Total: {train_c + val_c:4}")
    
    # Show sample image info
    if classes and os.path.exists(os.path.join(train_dir, classes[0])):
        sample_img_path = os.path.join(train_dir, classes[0], 
                                      os.listdir(os.path.join(train_dir, classes[0]))[0])
        try:
            with Image.open(sample_img_path) as img:
                print(f"\nSample image info:")
                print(f"  Path: {sample_img_path}")
                print(f"  Format: {img.format}")
                print(f"  Size: {img.size}")
                print(f"  Mode: {img.mode}")
        except Exception as e:
            print(f"Could not load sample image: {e}")

def main():
    """Main function to download and inspect ImageNette 160px"""
    print("ImageNette 160px Downloader and Inspector")
    print("=" * 50)
    
    # Download dataset
    data_path = download_imagenette_160("./data")
    
    # Show information
    load_imagenette_info(data_path)
    
    print("\n" + "="*50)
    print("Download and inspection complete!")
    print("="*50)

if __name__ == "__main__":
    main()