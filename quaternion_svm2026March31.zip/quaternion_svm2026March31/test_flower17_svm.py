import numpy as np
from quaternion_smm.core.real_quaternion_svm import BinaryQuaternionSVM
from quaternion_smm.data.flower17_loader import load_flower17_samples
from utils import evaluate_model, print_metrics


def image_to_quaternion_dict(X):
    """将图像数据转换为四元数dict格式"""
    n = X.shape[0]
    X = X.astype(np.float32) / 255.0
    
    R = X[:, :, :, 0]
    G = X[:, :, :, 1]
    B = X[:, :, :, 2]
    
    X_real = np.zeros((n, 64*64))  # 64x64 images
    X_i = R.reshape(n, -1)
    X_j = G.reshape(n, -1)
    X_k = B.reshape(n, -1)
    
    return {'real': X_real, 'i': X_i, 'j': X_j, 'k': X_k}


def test_parameters(C_val, gamma_val, rho_val, mu_val, max_iter_val=2000):
    """Test a specific parameter combination"""
    print(f"\nTesting: C={C_val}, gamma={gamma_val}, rho={rho_val}, mu={mu_val}, max_iter={max_iter_val}")
    
    np.random.seed(42)
    
    # Load Flowers-17 data (binary classification: first 2 classes)
    X, y = load_flower17_samples(n_per_class=30, k=2)  # 30 samples per class for binary classification
    X_dict = image_to_quaternion_dict(X)
    
    # Split data
    test_ratio = 0.2
    n_train = int(len(y) * (1 - test_ratio))
    X_train_dict = {k: v[:n_train] for k, v in X_dict.items()}
    X_test_dict = {k: v[n_train:] for k, v in X_dict.items()}
    y_train, y_test = y[:n_train], y[n_train:]
    
    print(f"Train: {y_train.shape[0]}, Test: {y_test.shape[0]}")
    print(f"  y_train unique: {np.unique(y_train)}")
    print(f"  y_test unique: {np.unique(y_test)}")
    
    # Create and train model
    rq_svm = BinaryQuaternionSVM(
        C=C_val, 
        gamma=gamma_val, 
        max_iter=max_iter_val, 
        rho=rho_val, 
        mu=mu_val, 
        verbose=False  # Set to False for cleaner output during tuning
    )
    rq_svm.fit(X=X_train_dict, y=y_train, X_test=X_test_dict, y_test=y_test)
    
    # Evaluate
    train_metrics, test_metrics = evaluate_model(
        rq_svm, X_train_dict, y_train, X_test_dict, y_test, use_decision_function=False
    )
    
    test_acc = test_metrics['accuracy']
    print(f"  Test Accuracy: {test_acc:.4f}")
    
    return test_acc


def main():
    print("Parameter Tuning for BinaryQuaternionSVM on Oxford Flowers-17")
    print("=" * 65)
    
    # Test a few parameter combinations
    test_configs = [
        # (C, gamma, rho, mu)
        (1.0, 0.004, 0.003, 0.2),  # Original from STL-10 test
        (1.0, 0.002, 0.3, 0.2),    # Best from STL-10 tuning
        (0.5, 0.002, 0.3, 0.2),    # Lower C
        (2.0, 0.002, 0.3, 0.2),    # Higher C
        (1.0, 0.001, 0.3, 0.2),    # Lower gamma
        (1.0, 0.008, 0.3, 0.2),    # Higher gamma
        (1.0, 0.002, 0.1, 0.2),    # Lower rho
        (1.0, 0.002, 0.5, 0.2),    # Higher rho
        (1.0, 0.002, 0.3, 0.1),    # Lower mu
        (1.0, 0.002, 0.3, 0.5),    # Higher mu
    ]
    
    best_acc = 0.0
    best_params = None
    
    for i, (C_val, gamma_val, rho_val, mu_val) in enumerate(test_configs):
        acc = test_parameters(C_val, gamma_val, rho_val, mu_val, max_iter_val=1000)
        if acc > best_acc:
            best_acc = acc
            best_params = {'C': C_val, 'gamma': gamma_val, 'rho': rho_val, 'mu': mu_val}
            print(f"  *** New best! ***")
    
    print("\n" + "=" * 65)
    print("Tuning Complete")
    print("=" * 65)
    print(f"Best accuracy: {best_acc:.4f}")
    print(f"Best parameters: C={best_params['C']}, gamma={best_params['gamma']}, "
          f"rho={best_params['rho']}, mu={best_params['mu']}")
    
    # Final test with best parameters
    print("\n" + "=" * 50)
    print("Final evaluation with best parameters")
    print("=" * 50)
    final_acc = test_parameters(
        best_params['C'], 
        best_params['gamma'], 
        best_params['rho'], 
        best_params['mu'],
        max_iter_val=2000
    )
    print(f"Final test accuracy: {final_acc:.4f}")


if __name__ == "__main__":
    main()